local addonName, addon = ...;

-- luacheck: globals ApesUIDB ApesUICDB

local DF = _G["DetailsFramework"];

addon.color = "FF8788EE";
addon.colorRGB = {0.514,0,1};
addon.colorRGBA = {0.514,0,1,1};
addon.colorHighlightRGBA = {0.529,0.533,0.933,1};
addon.colorTextHighlightRGBA = addon.colorHighlightRGBA;
addon.colorTextHighlight = "FF8788EE";

addon.lableTemplate = {
	font = "Expressway",
};


DF.button_templates["APESUI_BUTTON_TEMPLATE"] = CopyTable(DF.dropdown_templates["OPTIONS_DROPDOWN_TEMPLATE"]);
local buttonTemplate = DF.button_templates["APESUI_BUTTON_TEMPLATE"];
buttonTemplate.backdropcolor = {0.067,0.067,0.067,0.6};
buttonTemplate.onentercolor = {0.067,0.067,0.067,0.4};

function addon:CreateLabel(...)
	local label = DF:CreateLabel(...);
	label:SetTemplate(addon.lableTemplate);
	return label;
end

local metaVersion = GetAddOnMetadata(addonName,"Version");
addon.version = tonumber(metaVersion);
addon.frames = {};

local dbDefaults = {
	imports = {};
};

function addon:AddonPrint(...)
	print("|c"..addon.colorTextHighlight .."ApesUIInstall|r:",tostringall(...));
end

function addon:AddonPrintError(...)
	print("|cffff0000ApesUIInstall|r|cffff9117:|r",tostringall(...));
end

function addon:ShowFrame()
	addon.frames.mainFrame:Show();
end

function addon:HideFrame()
	addon.frames.mainFrame:Hide();
end

function addon:ToggleFrame()
	if(addon.frames.mainFrame:IsShown())then
		addon:HideFrame();
	else
		addon:ShowFrame();
	end
end

function addon:GetDisplayResolution()
	return GetPhysicalScreenSize();
end

function addon:CreateImportFrame(parent,addonName,addonLogo,addonLogoWidth,addonLogoHeight,importFunction)
	local container = CreateFrame("Frame",nil,parent);

	local profileText = addon:CreateLabel(container,"",16);
	profileText:SetPoint("TOPLEFT",container,"TOPLEFT");

	local importProfileButton = DF:CreateButton(container, nil, 80, 20, "Import", nil, nil, nil, nil, nil, nil, buttonTemplate,addon.lableTemplate);
	importProfileButton:SetPoint("LEFT",profileText,"RIGHT",10);
	importProfileButton.text_overlay:SetFont(importProfileButton.text_overlay:GetFont(),14);
	importProfileButton:SetClickFunction(importFunction);

	container:SetHeight(90 + (addonLogoHeight or 0));

	local lastImportLabel = addon:CreateLabel(container,"Last Import Time:",14,nil,addon.font);
	lastImportLabel:SetPoint("TOPRIGHT",profileText,"BOTTOMRIGHT",0,-3);
	local versionLabel = addon:CreateLabel(container,"Version:",14,nil,addon.font);
	versionLabel:SetPoint("TOPRIGHT",lastImportLabel,"BOTTOMRIGHT",0,-3);

	local lastImportText = addon:CreateLabel(container,"",14,nil,addon.font);
	lastImportText:SetPoint("LEFT",lastImportLabel,"RIGHT",10,0);
	local versionText = addon:CreateLabel(container,"",14,nil,addon.font);
	versionText:SetPoint("LEFT",versionLabel,"RIGHT",10,0);

	if(addonLogo)then
		local logo = DF:CreateImage(container,addonLogo,addonLogoWidth,addonLogoHeight);
		logo:SetPoint("TOP",container,"TOP",0,-70);

		container.logo = logo;
	end

	local function update()
		local addonLoaded = IsAddOnLoaded(addonName);
		local addonRealName = addonLoaded and select(2,GetAddOnInfo(addonName)) or addonName;

		profileText:SetText("|c"..addon.colorTextHighlight..addonRealName.." profile|r:");
		container:SetWidth(profileText:GetStringWidth() + 100);

		if(not addonLoaded)then
			importProfileButton:Disable();
			importProfileButton:SetText("Addon not loaded :(");
		else
			importProfileButton:Enable();
			importProfileButton:SetText("Import");
		end
		importProfileButton:SetWidth(importProfileButton.button.text:GetStringWidth() + 10);
	end

	container:SetScript("OnShow",update);

	container.lastImportText = lastImportText;
	container.versionText = versionText;

	return container;
end

function addon:HandleAceDBBullshit(database,import)

	for profileName,profile in pairs(import.profiles) do
		database.profiles[profileName] = CopyTable(profile);
	end

	if(import.namespaces)then
		for namespaceName,namespace in pairs(import.namespaces) do
			if(namespace.profiles)then
				for namespacesProfileName,namespacesProfile in pairs(namespace.profiles)do
					if(database.namespaces[namespaceName])then
						if(not database.namespaces[namespaceName].profiles)then
							database.namespaces[namespaceName].profiles = {};
						end
						database.namespaces[namespaceName].profiles[namespacesProfileName] = CopyTable(namespacesProfile);
					end
				end
			end
		end
	end
end

local function SlashCmdList_AddSlashCommand(name, func, ...)
	SlashCmdList[name] = func
	local command = ''
	for i = 1, select('#', ...) do
		command = select(i, ...)
		_G['SLASH_'..name..i] = command
	end
end

local selectPage;
do
	addon.frames.eventListener = CreateFrame("Frame");
	addon.frames.eventListener:RegisterEvent("PLAYER_ENTERING_WORLD");
	addon.frames.eventListener:RegisterEvent("ADDON_LOADED");

	local function handleDBLoad(database)
		for k,v in pairs(dbDefaults) do
			if(not database[k])then
				database[k] = v;
			end
		end
	end

	local function shouldShow()
		return not ApesUICDB.pressedDone or ((ApesUICDB.lastVersion or 0) < addon.version) or (ApesUICDB.openPage ~= nil);
	end

	local shown = false;
	addon.frames.eventListener:SetScript("OnEvent",function(self,event,...)
		if(event == "PLAYER_ENTERING_WORLD" and not shown)then
			if(shouldShow())then
				addon:ShowFrame();
				ApesUICDB.lastVersion = addon.version;

				if(ApesUICDB.selectedImportIndex)then
					addon.selectedImport = addon.imports[ApesUICDB.selectedImportIndex];
					addon.selectedImportIndex = ApesUICDB.selectedImportIndex;

					ApesUICDB.selectedImportIndex = nil;
				end

				ApesUICDB.openPage = nil;
			end
			shown = true;
		elseif(event == "ADDON_LOADED")then
			local loadedAddonName = ...;
			if(loadedAddonName == addonName)then
				ApesUIDB = ApesUIDB or {};
				ApesUICDB = ApesUICDB or {};

				handleDBLoad(ApesUIDB);
				handleDBLoad(ApesUICDB);

				selectPage(ApesUICDB.openPage or 1);

				SlashCmdList_AddSlashCommand("ApesUISHOW",function()selectPage(1);addon:ShowFrame();end,"/apes");
			end
		end
	end);
end

local function createPages(parent)
	for i,page in ipairs(addon.pagePrototypes)do
		page:Create(parent);
	end
end

function selectPage(index)
	addon.selectedPage = index;
	addon.shownPages = 0;
	for i,page in ipairs(addon.pagePrototypes) do
		if(not page:ShouldShow())then
			page:Hide();
		else
			addon.shownPages = addon.shownPages + 1;
			if(addon.shownPages == index)then
				page:Show();
			else
				page:Hide();
			end
		end
	end

	if(addon.selectedPage == 1)then
		addon.frames.mainFrame.prevButton:Hide();
	else
		addon.frames.mainFrame.prevButton:Show();
	end

	if(addon.selectedPage == addon.shownPages)then
		addon.frames.mainFrame.nextButton:SetText("Done!");
	else
		addon.frames.mainFrame.nextButton:SetText("Next >>");
	end
end

local function selectNextPage()
	if(addon.selectedPage < addon.shownPages)then
		selectPage(addon.selectedPage + 1);
	elseif(addon.selectedPage == addon.shownPages)then
		addon.frames.mainFrame:Hide();
		ApesUICDB.pressedDone = true;
	end
	ApesUICDB.openPage = nil;
end

local function selectPrevPage()
	if(addon.selectedPage > 1)then
		selectPage(addon.selectedPage - 1);
	end
	ApesUICDB.openPage = nil;
end

function addon:SkipPage()
	selectNextPage();
end

local function createFrames()
	local frame = DF:CreateSimplePanel(UIParent, 500, 400,"Apes UI Install V"..metaVersion);
	frame.Title:SetFont(frame.Title:GetFont(),16);
	frame.Title:SetPoint("CENTER",frame.TitleBar,"CENTER",0,1);

	DF:ApplyStandardBackdrop(frame);

	DF:CreateBorder(frame);
	frame:SetBorderColor(unpack(addon.colorRGBA));
	frame:SetLayerVisibility(false,false,false);

	frame:ClearAllPoints();
	frame:SetFrameStrata ("DIALOG");
	frame:SetFrameLevel(100);
	frame:SetPoint("CENTER",UIParent,"CENTER");

	local prevButton = DF:CreateButton(frame, nil, 80, 25, "<< Prev", nil, nil, nil, nil, nil, nil, buttonTemplate,addon.lableTemplate);
	prevButton:SetPoint("BOTTOMLEFT",frame,"BOTTOMLEFT",5,5);
	prevButton.text_overlay:SetFont(prevButton.text_overlay:GetFont(),14);
	prevButton.text_overlay:SetTextColor(unpack(addon.colorTextHighlightRGBA));
	prevButton:SetClickFunction(selectPrevPage);
	prevButton.onenter_backdrop_border_color = addon.colorHighlightRGBA;

	local nextButton = DF:CreateButton(frame, nil, 80, 25, "Next >>", nil, nil, nil, nil, nil, nil, buttonTemplate,addon.lableTemplate);
	nextButton:SetPoint("BOTTOMRIGHT",frame,"BOTTOMRIGHT",-5,5);
	nextButton.text_overlay:SetFont(nextButton.text_overlay:GetFont(),14);
	nextButton.text_overlay:SetTextColor(unpack(addon.colorTextHighlightRGBA));
	nextButton:SetClickFunction(selectNextPage);
	nextButton.onenter_backdrop_border_color = addon.colorHighlightRGBA;

	frame.prevButton = prevButton;
	frame.nextButton = nextButton;

	local frameContent = CreateFrame("Frame",nil,frame);
	frameContent:SetPoint("TOPLEFT",frame.TitleBar,"BOTTOMLEFT",0,-5);
	frameContent:SetPoint("TOPRIGHT",frame.TitleBar,"BOTTOMRIGHT",0,-5);
	frameContent:SetPoint("BOTTOMLEFT",frame,"BOTTOMLEFT",0,38);
	frameContent:SetPoint("BOTTOMRIGHT",frame,"BOTTOMRIGHT",0,38);
	frame.frameContent = frameContent;

	addon.frames.mainFrame = frame;

	createPages(frame);
	selectPage(1);
end

createFrames();

--C_Timer.After(1,function()addon:ShowFrame()end);