local addonName, addon = ...;
local DF = _G["DetailsFramework"];

addon.pagePrototypes = addon.pagePrototypes or {};
local page = {};
table.insert(addon.pagePrototypes,page);

function page:Create(parent)
	local frame = CreateFrame("Frame",nil,parent.frameContent);
	frame:SetAllPoints();

	local header = addon:CreateLabel(frame,"|c"..addon.colorTextHighlight.."Congratulations!|r",18);
	header:SetPoint("TOPLEFT",frame,"TOPLEFT",5,0);

	local textString = "|cFFFFFFFFYou have reached the end of the installation! Thanks for the support and have fun with your new UI!|r";
	local text = addon:CreateLabel(frame,textString,16);
	text:SetPoint("TOPLEFT",header,"BOTTOMLEFT",0,-10);
	text:SetPoint("BOTTOMRIGHT",frame,"BOTTOMRIGHT",-5,0);
	text:SetJustifyH("LEFT");
	text:SetJustifyV("TOP");

	local image = DF:CreateImage(frame,[[Interface\AddOns\ApesUIInstall\assets\APES.tga]],168,128);
	image:ClearAllPoints();
	image:SetPoint("CENTER",frame,"CENTER",0,-50);

	page.rootFrame = frame;
end

function page:ShouldShow()
	return true;
end

function page:Show()
	page.rootFrame:Show();
end

function page:Hide()
	page.rootFrame:Hide();
end