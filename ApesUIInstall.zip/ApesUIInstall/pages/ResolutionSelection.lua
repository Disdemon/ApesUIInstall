local addonName, addon = ...;
local DF = _G["DetailsFramework"];

addon.pagePrototypes = addon.pagePrototypes or {};
local page = {};
table.insert(addon.pagePrototypes,page);

local function selectImport(importIndex)
	addon.selectedImport = addon.imports[importIndex];
	addon.selectedImportIndex = importIndex;
	page.rootFrame:GetParent():GetParent().nextButton:Click();
end

function page:Create(parent)
	local frame = CreateFrame("Frame",nil,parent.frameContent);
	frame:SetAllPoints();

	local header = addon:CreateLabel(frame,"|c"..addon.colorTextHighlight.."Resolution selection:|r",18);
	header:SetPoint("TOPLEFT",frame,"TOPLEFT",5,0);

	local textString = "|cFFFFFFFFOn this page you should select what version of the UI you would like to import. 1440p or 1080p.|r";
	local text = addon:CreateLabel(frame,textString,16);
	text:SetWordWrap(true);
	text:SetPoint("TOPLEFT",header,"BOTTOMLEFT",0,-10);
	text:SetPoint("TOPRIGHT",frame,"TOPRIGHT",-5,-25);
	text:SetJustifyH("LEFT");
	text:SetJustifyV("TOP");

	local maxScreenResolutionData = C_VideoOptions.GetCurrentGameWindowSize();
    local maxScreenResolution = maxScreenResolutionData.x.."x"..maxScreenResolutionData.y

	local buttonTemplate = DF:GetTemplate("button", "APESUI_BUTTON_TEMPLATE");
	local button1440p = DF:CreateButton(frame, nil, 160, 40, maxScreenResolution == "2560x1440" and "|cff00ff001440p|r" or "|cffff00001440p|r", nil, nil, nil, nil, nil, nil, buttonTemplate, addon.lableTemplate);
	button1440p:SetPoint("LEFT",frame,"CENTER",60,-15);
	DF:SetFontSize(button1440p.button.text, 22);
	button1440p:SetClickFunction(function() selectImport(2); end);

	local button1080p = DF:CreateButton(frame, nil, 160, 40, maxScreenResolution == "1920x1080" and "|cff00ff001080p|r" or "|cffff00001080p|r", nil, nil, nil, nil, nil, nil, buttonTemplate, addon.lableTemplate);
	button1080p:SetPoint("RIGHT",frame,"CENTER",-60,-15);
	DF:SetFontSize(button1080p.button.text, 22);
	button1080p:SetClickFunction(function() selectImport(1); end);

	page.rootFrame = frame;
end

function page:ShouldShow()
	return true;
end

local didHide = false;
function page:Show()
	page.rootFrame:Show();
	page.rootFrame:GetParent():GetParent().nextButton:Hide();
	didHide = true;
end

function page:Hide()
	page.rootFrame:Hide();
	if(didHide)then
		page.rootFrame:GetParent():GetParent().nextButton:Show();
		didHide = false;
	end
end